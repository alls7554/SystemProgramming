#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h> //dirent.h은 파일 시스템의 디렉터리를 나타내기 위한 구조체를 가지고 있다.
#include <unistd.h> //unistd.h은 옵션을 위한 다양한 상수와 자료형 그리고 함수를 정의한다.
#include <sys/stat.h> // 파일의 각종 상태를 저장하는 구조체
#include <string.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

//파일 또는 디렉토리의 타입을 확인
void ls_Type(mode_t mmode){
    if(S_ISREG(mmode))
        putchar('-');
    else if(S_ISDIR(mmode))
        putchar('d');
    else if(S_ISCHR(mmode))
        putchar('c');
    else if(S_ISBLK(mmode))
        putchar('b');
    else if(S_ISFIFO(mmode))
        putchar('p');
    else if(S_ISLNK(mmode))
        putchar('l');
    else if(S_ISSOCK(mmode))
        putchar('s');
}

//파일 또는 디렉토리의 permission을 확인
void ls_Per(mode_t pmode){
    // User permission
    if(pmode&S_IRUSR)
        putchar('r');
    else
        putchar('-');
    if(pmode&S_IWUSR)
        putchar('w');
    else
        putchar('-');
    if(pmode&S_IXUSR)
        putchar('x');
    else
        putchar('-');

    // Group permission
    if(pmode&S_IRGRP)
        putchar('r');
    else
        putchar('-');
    if(pmode&S_IWGRP)
        putchar('w');
    else
        putchar('-');
    if(pmode&S_IXGRP)
        putchar('x');
    else
        putchar('-');

    //Other permission
    if(pmode&S_IROTH)
        putchar('r');
    else
        putchar('-');
    if(pmode&S_IWOTH)
        putchar('w');
    else
        putchar('-');
    if(pmode&S_IXOTH)
        putchar('x');
    else
        putchar('-');

}

// 파일 또는 디렉토리의 Link 수 확인
void ls_Linkcnt(nlink_t lcnt){
    printf("   %ld", lcnt);
}

// 유저아이디 출력
void ls_Uid(uid_t uid){
    struct passwd *uuid=(struct passwd*)malloc(sizeof(struct passwd));
    uuid=getpwuid(uid);
    printf("  %s",uuid->pw_name);
}


// 그룹아이디 출력
void ls_Gid(gid_t gid){
    struct group *grp = (struct group*)malloc(sizeof(struct group));
    grp = getgrgid(gid);
    printf("  %s", grp->gr_name);
}

// 파일 또는 디렉토리의 크기 확인
void ls_FSize(off_t sz){
    printf("%10ld  ", sz);
}

// 파일 또는 디렉토리의 최종 접근 시간 확인
void ls_FTime(time_t ttime){
    struct tm *tm_ptr;
    tm_ptr = localtime(&ttime);
    printf("  ");
    printf("%d월%2d일 %2d:%2d  ",tm_ptr->tm_mon+1, tm_ptr->tm_mday, tm_ptr->tm_hour, tm_ptr->tm_min);
}

// 파일 또는 디렉토리의 Inode 확인
void ls_Inode(ino_t inonum){
    printf("%16ld\t", inonum);
}

// 옵션 설정
void ls_option(struct stat buf, char * option){
    if(strstr(option, "al") || strstr(option, "l")){
        ls_Type(buf.st_mode);
        ls_Per(buf.st_mode);
        ls_Linkcnt(buf.st_nlink);
        ls_Uid(buf.st_uid);
        ls_Gid(buf.st_gid);
        ls_FSize(buf.st_size);
        ls_FTime(buf.st_mtime);
    }
    else if(strstr(option, "i") || strstr(option, "ai")){
        ls_Inode(buf.st_ino);
    }

    else if(strchr(option, 'l') && strchr(option, 'i')){
        ls_Inode(buf.st_ino);
        ls_Type(buf.st_mode);
        ls_Per(buf.st_mode);
        ls_Linkcnt(buf.st_nlink);
        ls_Uid(buf.st_uid);
        ls_Gid(buf.st_gid);
        ls_FSize(buf.st_size);
        ls_FTime(buf.st_mtime);
    }
    else if(strchr(option, 'a')){
        //구현되지 않은 기술에 대한 메세지 출력을 하기 위한 빈 조건문
        // 빈 조건문인 이유는 메인함수의 while loop문에서 처리되기 때문이다.
     }   
    else{ // 구현되지 않은 기술에 대한 에러 메세지 출력 후 프로그램 종료
        printf("'%s' is unimplemented technology\n", option);
        exit(1);
    }
}

int main(int argc, char* argv[]){  
    char *cwd = (char*)malloc(sizeof(char)*1024);
    memset(cwd, 0, 1024);

    DIR* dir = NULL;
    struct dirent* entry;
    struct stat buf;

    getcwd(cwd, 1024); //작업 디렉토리의 전체 이름을 구합니다.

    //open한 dir가 존재하지 않으면 문구 출력 후 종료
    if((dir = opendir(cwd)) == NULL){
        printf("opendir error\n");
        exit(1);
    }

    while((entry = readdir(dir)) != NULL){
        lstat(entry->d_name, &buf);
        
        // 옵션이 있는 경우
        if(argc > 1){  
            // 옵션에 a가 포함되어 있지 않고(AND) 파일(또는 디렉토리)의 이름이 .으로 시작하는 경우
            // Linux에서 일반적으로 .으로 시작하는 파일(또는 디렉토리) 은(는) 숨김파일(또는 디렉토리)이다.
            if(strchr(argv[1], 'a') == NULL && strspn((entry->d_name), "."))
                continue;

            ls_option(buf, argv[1]);
            printf("%s\n", entry->d_name);
        }

        else{
            if(strspn((entry->d_name), ".")) 
            // 옵션이 a가 포함되어 있지만 파일(또는 디렉토리)의 이름이 .으로 시작하는 경우
                continue;
            printf("%s\n", entry->d_name); // 그렇지 않으면 출력
        }

    }

    free(cwd); //동적할당된 메모리를 풀어준다.
    closedir(dir); //dir를 닫는다.

    return 0;
}

