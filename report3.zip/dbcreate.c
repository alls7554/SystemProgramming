#include "student.h"

void dbcreate(char *name)
{
	int fd;
	struct student rec;

	if ((fd = open(name, O_WRONLY |O_CREAT, 0640))==-1) {
		perror(name);
		exit(2);
	}

	printf("%-9s %-8s %-4s", "학번",  "이름",  "점수\n"); 
	while (scanf("%d %s %d", &rec.id, rec.name, &rec.score) ==  3) {
		lseek(fd, (rec.id - START_ID) * sizeof(rec), SEEK_SET);
		write(fd, &rec, sizeof(rec) );
	}

	close(fd);
	exit(0);

}
