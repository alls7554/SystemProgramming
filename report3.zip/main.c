#include "student.h"

void dbcreate(char *);
void dbquery(char *);
void dbupdate(char *);

int main (int argc, char *argv[]){
    int menu;

    if (argc < 2) {
        fprintf(stderr,  "사용법 : %s file\n", argv[0]);
        exit(1);
    }

    while(1) {
        printf("1. CreateDB\n2. QueryDB\n3. UpdateDB\n0. EXIT\n  >>> : ");
        scanf("%d", &menu);

        if(menu == 1){
            dbcreate(argv[1]);
        }
        else if(menu == 2){
            dbquery(argv[1]);
        }
        else if(menu == 3){
            dbupdate(argv[1]);   
        }
        else if(menu == 0){
            exit(0);
        }
        else{
            printf("Invalid Input");
        }
    }
}
