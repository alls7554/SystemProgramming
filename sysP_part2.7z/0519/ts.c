#include <stdio.h>
#include <stdlib.h>

int main(){

    char i1, i2;
    
    printf("대문자 입력 : ");
    scanf("%c", &i1);
    getchar();

    printf("소문자 입력 : ");
    scanf("%c", &i2);

    printf("입력한 대문자 %c의 소문자는 %c입니다.\n", i1, i1+32);
    printf("입력한 소문자 %c의 대문자는 %c입니다.\n", i2, i2-32);
    
    return 0;
}
