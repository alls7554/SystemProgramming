<? 
echo "Hello PHP World!!";
?>
